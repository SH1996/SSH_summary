package is.ajax;

import java.util.HashMap;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import net.sf.json.JSONObject;

public class Demo extends ActionSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  String result;
	private String name;
	private String pwd;
	

	@Override
	public String execute() throws Exception {
		
		return SUCCESS;
	}
	
	public String Ajax_() throws Exception {
//		ActionContext actionContext = ActionContext.getContext();
		if(name.equals("tom") && pwd.equals("123")) {
			
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("name_", "name_yes");
			map.put("pwd_","pwd_yes");
			JSONObject json = JSONObject.fromObject(map);
			result = json.toString();
		}else {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("name_", "name_no");
			map.put("pwd_","pwd_no");
			JSONObject json = JSONObject.fromObject(map);
			result = json.toString();
		    
		}
		 return SUCCESS;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
